<!DOCTYPE html>
<html>
	<head>
		<title>Toko Bunga Lisna Florist</title>
	</head>

		<frameset rows="15%,*,5%" border="0">
			<frame name="atas" src="logo.php" />
			<frameset cols="20%,*">
				<frame name="menu" scrolling="no" src="menu.php" />
				<frame name="isi" src="beranda.php"/>
			</frameset>
			<frame name="bawah" scrolling="no" src="logo2.php" />
		</frameset>
</html> 