<!DOCTYPE html>
<html>
<body bgcolor="#006699">
<h1><font color="#FFFFFF">WEB PENGELOLAAN DATA BUNGA DAN PENJUALAN</font></h1>
</body>
</html>