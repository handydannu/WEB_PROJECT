<!DOCTYPE HTML>
<html>
   <body>
   <center>
	
    <hr size="4" width="auto" color="#B62ECE">
       <h1>PENGELOLAAN DATA BUNGA DAN PENJUALAN BUNGA</h1>
    <hr size="4" width="auto" color="#B62ECE">

    <h3>SELAMAT DATANG ADMIN DI PENGELOLAAN DATA BUNGA 
        DAN PENJUALAN<br/>
        PT. LISNA FLORIST
    </H3>
    <hr size="4" width="auto" color="#B62ECE">
    </center>
</body>
</html>