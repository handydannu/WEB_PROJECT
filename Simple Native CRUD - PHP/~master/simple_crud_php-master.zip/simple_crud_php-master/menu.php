<html>
<head>
<title></title>
</head>
<body bgcolor="#CCCCFF">
<h2>Navigasi</h2>
<hr size="2">
<ul>	
	<h3><a href="beranda.php" target="isi">Home</a></h3>
	<h3><a href="tambahbunga.php" target="isi">Masuk</a></h3>
	<h3><a href="tampildata.php" target="isi">Tampil</a></h3>
	<h3><a href="cari.php" target="isi">Cari</a></h3>
	<h3><a href="cariedit.php" target="isi">Edit</a></h3>
	<h3><a href="carihapus.php" target="isi">Hapus</a></h3>
	<h3><a href="penjualan.php" target="isi">Penjualan</a></h3>
</ul>
</body>
</html>