<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>PROGRAM PEMODELAN SIMULASI DENGAN PHP</title>
    <link href="css/mosi_style.css" type="text/css" rel="stylesheet" /> 
    	
    <script type="text/javascript" src="js/jquery.min.js"></script> 
    <script type="text/javascript" src="js/jquery.scrollTo-min.js"></script> 
    <script type="text/javascript" src="js/jquery.localscroll-min.js"></script> 
    <script type="text/javascript" src="js/init.js"></script> 
        
    <link rel="stylesheet" href="css/slimbox2.css" type="text/css" media="screen" /> 
    <script type="text/JavaScript" src="js/slimbox2.js"></script> 