<center>
	<form method="post" name"hitung" action="tabelhitung.php">
		<table id="box-table-c" align="center">
		  <tr>
		  	<th>Nomor</th>
		    <th>DATA X</th>
		    <th>DATA Y</th>
		  </tr>
		  <tr>
		  	<td>1</td>
		    <td><input type="text" name="x1" value="0" class="input_field" maxlength="8" /></td>
		    <td><input type="text" name="y1" value="0" class="input_field" maxlength="8" /></td>
		  </tr>
		  <tr>
		  	<td>2</td>
		    <td><input type="text" name="x2" value="0" class="input_field" maxlength="8" /></td>
		    <td><input type="text" name="y2" value="0" class="input_field" maxlength="8" /></td>
		  </tr>
		  <tr>
		  	<td>3</td>
		    <td><input type="text" name="x3" value="0" class="input_field" maxlength="8" /></td>
		    <td><input type="text" name="y3" value="0" class="input_field" maxlength="8" /></td>
		  </tr>
		  <tr>
		  	<td>4</td>
		    <td><input type="text" name="x4" value="0" class="input_field" maxlength="8" /></td>
		    <td><input type="text" name="y4" value="0" class="input_field" maxlength="8" /></td>
		  </tr>
		  <tr>
		  	<td>5</td>
		    <td><input type="text" name="x5" value="0" class="input_field" maxlength="8" /></td>
		    <td><input type="text" name="y5" value="0" class="input_field" maxlength="8" /></td>
		  </tr>
		  <tr>
		  	<td>6</td>
		    <td><input type="text" name="x6" value="0" class="input_field" maxlength="8" /></td>
		    <td><input type="text" name="y6" value="0" class="input_field" maxlength="8" /></td>
		  </tr>
		  <tr>
		  	<td>7</td>
		    <td><input type="text" name="x7" value="0" class="input_field" maxlength="8" /></td>
		    <td><input type="text" name="y7" value="0" class="input_field" maxlength="8" /></td>
		  </tr>
		  <tr>
		  	<td>8</td>
		    <td><input type="text" name="x8" value="0" class="input_field" maxlength="8"  /></td>
		    <td><input type="text" name="y8" value="0" class="input_field" maxlength="8" /></td>
		  </tr>
		  <tr>
		  	<td>9</td>
		    <td><input type="text" name="x9" value="0" class="input_field" maxlength="8" /></td>
		    <td><input type="text" name="y9" value="0" class="input_field" maxlength="8" /></td>
		  </tr>
		  <tr>
		  	<td>10</td>
		    <td><input type="text" name="x10" value="0" class="input_field" maxlength="8" /></td>
		    <td><input type="text" name="y10" value="0" class="input_field" maxlength="8" /></td>
		  </tr>
		  <tr>
		  	<td>11</td>
		    <td><input type="text" name="x11" value="0" class="input_field" maxlength="8" /></td>
		    <td><input type="text" name="y11" value="0" class="input_field" maxlength="8" /></td>
		  </tr>
		  <tr>
		  	<td>12</td>
		    <td><input type="text" name="x12" value="0" class="input_field" maxlength="8" /></td>
		    <td><input type="text" name="y12" value="0" class="input_field" maxlength="8" /></td>
		  </tr>
		  <tr>
		  	<td>13</td>
		    <td><input type="text" name="x13" value="0" class="input_field" maxlength="8" /></td>
		    <td><input type="text" name="y13" value="0" class="input_field" maxlength="8" /></td>
		  </tr>
		  <tr>
		  	<td>14</td>
		    <td><input type="text" name="x14" value="0" class="input_field" maxlength="8" /></td>
		    <td><input type="text" name="y14" value="0" class="input_field" maxlength="8" /></td>
		  </tr>
		  <tr>
		  	<td>15</td>
		    <td><input type="text" name="x15" value="0" class="input_field" maxlength="8" /></td>
		    <td><input type="text" name="y15" value="0" class="input_field" maxlength="8" /></td>
		  </tr>
		  <tr>
		  	<td colspan="3"><input type="submit" value="HITUNG" id="submit" name="submit" class="submit_btn center" /></td>
		  </tr>
		</table>
	</form>
</center>