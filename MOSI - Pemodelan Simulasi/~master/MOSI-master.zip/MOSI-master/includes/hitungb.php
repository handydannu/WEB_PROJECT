  <br/><hr><br/>
  <p>Rumus menghitung b : </p>
                <img src ="images/rumusb.jpg" width="600px" height="150px" />
                <br><br><br>
<table>
  <tr>
    <th></th>
    <th></th>
    <th>(<?php echo $sigman; ?>)</th>
    <th>(<?php echo $sigmaxy; ?>)</th>
    <th>-</th>
    <th>(<?php echo $sigmax; ?>)</th>
    <th>x</th>
    <th>(<?php echo $sigma1y; ?>)</th>
  </tr>
  <tr>
    <td>b</td>
    <td>=</td>
    <td colspan="6">-------------------------------------------------------------------------</td>
  </tr>
  <tr>
    <td></td>
    <td></td>
    <td></td>
    <td>(<?php echo $sigman; ?>)</td>
    <td>(<?php echo $sigmaxx; ?>)</td>
    <td>-</td>
    <td>(<?php echo $sigmax2; ?>)</td>
    <td></td>
  </tr>
</table>
<br><br>
<h4> Nilai b = <?php echo $nilaib; ?></h4>