                </div>
                <?php include 'includes/regresi.php'; ?>                
                <?php include 'includes/hitungb.php'; ?>
                <?php include 'includes/hitunga.php'; ?>
                <br/>  