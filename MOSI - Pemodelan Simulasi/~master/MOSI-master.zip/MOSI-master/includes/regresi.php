 <table id="box-table-c" align="center">
                                  <tr>
                                    <th>Nomor</th>
                                    <th>Xi</th>
                                    <th>Yi</th>
                                    <th>(1/y)</th>
                                    <th>(x^2)</th>
                                    <th>(Xi/Yi)</th>
                                  </tr>
                                  <tr>
                                    <td>1</td>
                                    <td><?php echo $x1; ?></td>
                                    <td><?php echo $y1; ?></td>
                                    <td><?php echo $pery1; ?></td>
                                    <td><?php echo $xx1; ?></td>
                                    <td><?php echo $xy1; ?></td>
                                  </tr>
                                  <tr>
                                    <td>2</td>
                                    <td><?php echo $x2; ?></td>
                                    <td><?php echo $y2; ?></td>
                                    <td><?php echo $pery2; ?></td>
                                    <td><?php echo $xx2; ?></td>
                                    <td><?php echo $xy2; ?></td>
                                  </tr>
                                  <tr>
                                    <td>3</td>
                                    <td><?php echo $x3; ?></td>
                                    <td><?php echo $y3; ?></td>
                                    <td><?php echo $pery3; ?></td>
                                    <td><?php echo $xx3; ?></td>
                                    <td><?php echo $xy3; ?></td>
                                  </tr>
                                  <tr>
                                    <td>4</td>
                                    <td><?php echo $x4; ?></td>
                                    <td><?php echo $y4; ?></td>
                                    <td><?php echo $pery4; ?></td>
                                    <td><?php echo $xx4; ?></td>
                                    <td><?php echo $xy4; ?></td>
                                  </tr>
                                  <tr>
                                    <td>5</td>
                                    <td><?php echo $x5; ?></td>
                                    <td><?php echo $y5; ?></td>
                                    <td><?php echo $pery5; ?></td>
                                    <td><?php echo $xx5; ?></td>
                                    <td><?php echo $xy5; ?></td>
                                  </tr>
                                  <tr>
                                    <td>6</td>
                                    <td><?php echo $x6; ?></td>
                                    <td><?php echo $y6; ?></td>
                                    <td><?php echo $pery6; ?></td>
                                    <td><?php echo $xx6; ?></td>
                                    <td><?php echo $xy6; ?></td>
                                  </tr>
                                  <tr>
                                    <td>7</td>
                                    <td><?php echo $x7; ?></td>
                                    <td><?php echo $y7; ?></td>
                                    <td><?php echo $pery7; ?></td>
                                    <td><?php echo $xx7; ?></td>
                                    <td><?php echo $xy7; ?></td>
                                  </tr>
                                  <tr>
                                    <td>8</td>
                                    <td><?php echo $x8; ?></td>
                                    <td><?php echo $y8; ?></td>
                                    <td><?php echo $pery8; ?></td>
                                    <td><?php echo $xx8; ?></td>
                                    <td><?php echo $xy8; ?></td>
                                  </tr>
                                  <tr>
                                    <td>9</td>
                                    <td><?php echo $x9; ?></td>
                                    <td><?php echo $y9; ?></td>
                                    <td><?php echo $pery9; ?></td>
                                    <td><?php echo $xx9; ?></td>
                                    <td><?php echo $xy9; ?></td>
                                  </tr>
                                  <tr>
                                    <td>10</td>
                                    <td><?php echo $x10; ?></td>
                                    <td><?php echo $y10; ?></td>
                                    <td><?php echo $pery10; ?></td>
                                    <td><?php echo $xx10; ?></td>
                                    <td><?php echo $xy10; ?></td>
                                  </tr>
                                  <tr>
                                    <td>11</td>
                                    <td><?php echo $x11; ?></td>
                                    <td><?php echo $y11; ?></td>
                                    <td><?php echo $pery11; ?></td>
                                    <td><?php echo $xx11; ?></td>
                                    <td><?php echo $xy11; ?></td>
                                  </tr>
                                  <tr>
                                    <td>12</td>
                                    <td><?php echo $x12; ?></td>
                                    <td><?php echo $y12; ?></td>
                                    <td><?php echo $pery12; ?></td>
                                    <td><?php echo $xx12; ?></td>
                                    <td><?php echo $xy12; ?></td>
                                  </tr>
                                  <tr>
                                    <td>13</td>
                                    <td><?php echo $x13; ?></td>
                                    <td><?php echo $y13; ?></td>
                                    <td><?php echo $pery13; ?></td>
                                    <td><?php echo $xx13; ?></td>
                                    <td><?php echo $xy13; ?></td>
                                  </tr>
                                  <tr>
                                    <td>14</td>
                                    <td><?php echo $x14; ?></td>
                                    <td><?php echo $y14; ?></td>
                                    <td><?php echo $pery14; ?></td>
                                    <td><?php echo $xx14; ?></td>
                                    <td><?php echo $xy14; ?></td>
                                  </tr>
                                  <tr>
                                    <td>15</td>
                                    <td><?php echo $x15; ?></td>
                                    <td><?php echo $y15; ?></td>
                                    <td><?php echo $pery15; ?></td>
                                    <td><?php echo $xx15; ?></td>
                                    <td><?php echo $xy15; ?></td>
                                  </tr>
                                  <tr>
                                    <td colspan="6"></td>
                                  </tr>
                                  <tr align="center">
                                    <td></td>
                                    <td>Sigma Xi : </td>
                                    <td>Sigma Yi : </td>
                                    <td>Sigma (1/Yi) : </td>
                                    <td>Sigma X^2 : </td>
                                    <td>Sigma (Xi/Yi) : </td>
                                  </tr>
                                  <tr>
                                    <td></td>
                                    <td><?php echo $sigmax; ?></td>
                                    <td><?php echo $sigmay; ?></td>
                                    <td><?php echo $sigma1y; ?></td>
                                    <td><?php echo $sigmaxx; ?></td>
                                    <td><?php echo $sigmaxy; ?></td>
                                  </tr>
                                </table>
                            </form>