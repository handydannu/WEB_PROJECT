<div class="wrapper row4">
  <footer id="footer" class="clear"> 
    <!-- ################################################################################################ -->
    <div class="one_half first">
      <h6 class="title">Program apa ini ?</h6>
      	<p align="justify">Sebuah program yang digunakan untuk mendeteksi sekaligus mendiagnosa penyakit
      		batuk tipe apa yang diderita oleh pasien. Juga memberikan solusi sesuai dengan batuk yang 
      		sedang diderita.</p>
      </div>
    <div class="one_quarter">
      <h6 class="title">Pengembang</h6>
	      Handy Dannu W - 10111146<br/>
	      Adji Teja - <br/>
	      Joli Edhar -<br/>
    </div>
    <div class="one_quarter">
      <h6 class="title">Temukan kami</h6>
      <ul class="faico clear">
        <li><a class="faicon-facebook" href="#"><i class="icon-facebook"></i></a></li>
        <li><a class="faicon-twitter" href="#"><i class="icon-twitter"></i></a></li>
        <li><a class="faicon-google-plus" href="#"><i class="icon-google-plus"></i></a></li>
      </ul>
    </div>
    <!-- ################################################################################################ --> 
  </footer>
</div>

	<div class="wrapper row5">
	  <div id="copyright" class="clear"> 
	    <!-- ################################################################################################ -->
	    <p class="fl_left">Copyright &copy; 2014 - ANN - Deteksi Batuk - Kelompok 8 AI-6</p>
	    <!-- ################################################################################################ --> 
	  </div>
	</div>